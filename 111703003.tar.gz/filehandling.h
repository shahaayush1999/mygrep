#include <string.h>
#include <stdio.h>
#include <stdlib.h>

void appendlinetofile(char *filename, char *string);
void getline(FILE *fp, char *string);
