GREP
AAYUSH SHAH
111703003
COMPUTER ENGINEERING

# mygrep
Implements the shell command Grep along with 12 options
Options implemented are
-c
-m
-v
-r
-f
-e
-h
-H
-q
-b
